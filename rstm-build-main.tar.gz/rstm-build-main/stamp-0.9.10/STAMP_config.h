/**
 *  Copyright (C) 2011
 *  University of Rochester Department of Computer Science
 *    and
 *  Lehigh University Department of Computer Science and Engineering
 *
 * License: Modified BSD
 *          Please see the file LICENSE.RSTM for licensing information
 */

#ifndef STAMP_CONFIG_H
#define STAMP_CONFIG_H

/* #undef STAMP_USE_WAIVER */

#endif
